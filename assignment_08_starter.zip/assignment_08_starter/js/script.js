window.addEventListener('load', () => {
    
    //startClock();
    //YOUR CODE SHOULD START BELOW THIS LINE



});